﻿namespace MyCustomDiscordBot.Services
{
    public class PugService
    {
        public PugService()
        {

        }
    }
}
