﻿namespace MyCustomDiscordBot.Settings
{
    public class BotSettings
    {
        public string Token { get; set; }
        public ulong Id { get; set; }
        public char Prefix { get; set; }
    }
}
