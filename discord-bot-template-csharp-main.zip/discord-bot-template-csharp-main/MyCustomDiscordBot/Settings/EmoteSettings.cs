﻿namespace MyCustomDiscordBot.Settings
{
    public class EmoteSettings
    {
    }
}
