﻿namespace MyCustomDiscordBot.Settings
{
    public class GameSettings
    {
        public int TeamSize { get; set; }
        public string GameName { get; set; }
    }
}
