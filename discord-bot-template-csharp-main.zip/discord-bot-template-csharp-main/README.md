# discord-bot-template-csharp
Change appsettings.json to include your token and bot Id.

# Looking for a template to start your Discord bot in C#?
Look no further!

## Some basic features of this template 
+ Worker service and dependency injection
+ Discord.Commands structure with modules
+ Settings pulled from appSettings.JSON

Reducing boilerplate code since 2020... thank me at contact@tylersandoe.com or on Discord (Derd#1385)

Enjoy!
