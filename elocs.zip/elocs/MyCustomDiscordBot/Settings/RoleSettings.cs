﻿namespace MyCustomDiscordBot.Settings
{
    public class RoleSettings
    {
    }
}
