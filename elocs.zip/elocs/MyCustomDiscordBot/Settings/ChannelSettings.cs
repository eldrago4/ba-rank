﻿namespace MyCustomDiscordBot.Settings
{
    public class ChannelSettings
    {
        
    }
}
